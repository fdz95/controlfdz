<footer class="main-footer">
	<strong>Copyright &copy; <?php echo date('Y'); ?> <a href="#"><?php echo $author; ?></a>.</strong> All rights reserved.
	<div class="float-right d-none d-sm-inline-block"><b>Version</b> <?php echo $version;?></div>
</footer>