<div id="deleteUserModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="delete_user_modal" id="delete_user_modal">
				<div class="modal-header">						
					<h4 class="modal-title">Borrar usuario</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<p><label id="id_delete_title_user"></label></p>
					<input type="hidden" name="id_delete_user" id="id_delete_user">
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
					<input type="submit" class="btn btn-danger" value="Borrar">
				</div>
			</form>
		</div>
	</div>
</div>