<div id="addTipoTrabajoModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="form_add_tipo_trabajo" id="form_add_tipo_trabajo">
				<div class="modal-header">
					<h4 class="modal-title">Agregar</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<label>Agregar tipo de trabajo</label>
					<input type="text" name="add_tipo_trabajo" id="add_tipo_trabajo" placeholder="Tipo de trabajo..." class="form-control" />&nbsp;&nbsp;&nbsp;
					<div class="form-group">
						<label id="response_add_tipo_trabajo"></label>
					</div>
				</div>
				<div class="modal-footer justify-content-between">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
					<input type="submit" id="button_tipo_trabajo" class="btn btn-success" value="Agregar">
				</div>
			</form>
		</div>
	</div>
</div>