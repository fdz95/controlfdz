<div id="pagosTrabajoModal2" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<h4 class="modal-title">Pagos</h4>
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
			</div>
			<div class="modal-body">
				<div class="form-group">
					<label id="label_pago_trabajo2"></label>
				</div>
				<hr>
				<div class="form-group">
					<div id="historial_pagos2" class="form-group"></div>
				</div>
			</div>
			<div class="modal-footer justify-content-between">
				<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
			</div>
		</div>
	</div>
</div>