<div id="generarCotizModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="generar_cotiz_modal" id="generar_cotiz_modal">
				<div class="modal-header">						
					<h4 class="modal-title">Generar cotizaci&oacute;n</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<p><label id="title_generar_cotiz"></label></p>
					<input type="hidden" name="id_generar_cotiz" id="id_generar_cotiz">
					<input type="hidden" name="id_generar_cotiz_cliente" id="id_generar_cotiz_cliente">
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
					<input type="submit" class="btn btn-success" value="Generar">
				</div>
			</form>
		</div>
	</div>
</div>