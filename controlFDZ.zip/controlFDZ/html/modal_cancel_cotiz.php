<div id="cancelCotizModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="cancel_cotiz_modal" id="cancel_cotiz_modal">
				<div class="modal-header">						
					<h4 class="modal-title">Cancelar cotizaci&oacute;n</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<p><label id="title_cancel_cotiz"></label></p>
					<input type="hidden" name="id_cancel_cotiz" id="id_cancel_cotiz">
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cerrar">
					<input type="submit" class="btn btn-danger" value="Cancelar cotizaci&oacute;n">
				</div>
			</form>
		</div>
	</div>
</div>