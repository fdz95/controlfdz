<div id="deleteGastoModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="delete_gasto_modal" id="delete_gasto_modal">
				<div class="modal-header">						
					<h4 class="modal-title">Borrar gasto</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<p><label id="title_delete_gasto"></label></p>
					<input type="hidden" name="id_delete_gasto" id="id_delete_gasto">
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
					<input type="submit" class="btn btn-danger" value="Borrar">
				</div>
			</form>
		</div>
	</div>
</div>