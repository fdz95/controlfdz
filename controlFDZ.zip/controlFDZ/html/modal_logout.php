<div id="logoutModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<form name="logout_modal" id="logout_modal">
				<div class="modal-header">						
					<h4 class="modal-title">Cerrar sesi&oacute;n</h4>
					<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				</div>
				<div class="modal-body">
					<label id="label_logout">¿Realmente desea salir del sistema?</label>
				</div>
				<div class="modal-footer">
					<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancelar">
					<input type="submit" id="button_logout" class="btn btn-danger" value="Salir">
				</div>
			</form>
		</div>
	</div>
</div>