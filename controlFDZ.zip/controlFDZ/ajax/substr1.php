<?php


	$num_pais = substr("542915321901",0,2);
	$num_celular = substr("542915321901",2);
	
	echo "Pais: ". $num_pais ."</br></br>Celular: ". $num_celular;
?>